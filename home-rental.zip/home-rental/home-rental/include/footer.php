    
    <script src="../assets/plugins/jquery/jquery.min.js"></script>
    <script src="../assets/plugins/bootstrap/js/bootstrap.min.js"></script>

    
    <script src="../assets/plugins/jquery-easing/jquery.easing.min.js"></script>

     <script src="../assets/js/jqBootstrapValidation.js"></script>
    <script src="../assets/js/contact_me.js"></script>

   
    <script src="../assets/js/rent.js"></script>
  </body>
</html>
